import java.io.FileWriter;
import java.io.IOException;
public class WayFinder {
    private City[] cities;
    private int[][] timeMatrix;

    public WayFinder(City[] cities, int[][] timeMatrix){
        this.cities = cities;
        this.timeMatrix = timeMatrix;
    }

    private int getIndex(String cityName){
        for (int i=0 ; i<cities.length ; i++){
            if (cities[i].getCityName().equals(cityName)) return i;
        }
        return -1;
    }

    private int getMinDistance(int[] distances, boolean[] visited){
        int min = Integer.MAX_VALUE;
        int closestIndex = -1;

        for (int i=0 ; i<cities.length ; i++){
            if (!visited[i] && distances[i]<min){
                min = distances[i];
                closestIndex = i;
            }
        }
        return closestIndex;
    }

    private void writeToFile(FileWriter wr, String output) {
       try{
           wr.write(output);
       }
       catch(IOException e){
           System.out.println("Error");
       }
    }

    public void printPath(FileWriter wr, int[] previous, int start, int end){
        if (end == -1){
            return;
        }
        printPath(wr, previous, start, previous[end]);
        try{
            if (end!=start){
                wr.write("->");
            }
            wr.write(cities[end].getCityName());
        }
        catch(IOException e){
            System.out.println("Error");
        }
    }


    public void findFastestRoute (String startCity, String endCity){
        int startIndex = getIndex(startCity);
        int endIndex = getIndex(endCity);

        try (FileWriter wr = new FileWriter("output.txt")){
            if (startIndex == -1 || endIndex == -1) {
                System.out.println("Error. Invalid city.");
                return;
            }
            boolean[] visited = new boolean[cities.length];
            int[] distance = new int[cities.length]; //shortest
            int[] previous = new int[cities.length];

            for (int i = 0; i < cities.length; i++) {
                visited[i] = false;
                distance[i] = Integer.MAX_VALUE;
                previous[i] = -1;
            }
            distance[startIndex] = 0;

            for (int i = 0; i < cities.length; i++) {
                int current = getMinDistance(distance, visited);
                visited[current] = true;

                for (int neighbour = 0; neighbour < cities.length; neighbour++) {
                    if (!visited[neighbour] && timeMatrix[current][neighbour] != -1 && distance[current] != Integer.MAX_VALUE) {
                        int newDistance = distance[current] + timeMatrix[current][neighbour];
                        if (newDistance < distance[neighbour]) {
                            distance[neighbour] = newDistance;
                            previous[neighbour] = current;
                        }
                    }
                }
            }

            if (distance[endIndex] == Integer.MAX_VALUE) {
                writeToFile(wr, "Error. Reason: No path exist.");
            } else {
                printPath(wr, previous, startIndex, endIndex);
                wr.write(" Total Time: " + distance[endIndex] + " minutes");
            }
            System.out.println("Check output.");
        }catch(IOException e){
            System.out.println("Error");
        }
    }

}
