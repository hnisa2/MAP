import java.io.File;
import java.io.IOException;
import java.util.Scanner;
public class CountryMap {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Input file?");
            return;
        }

        String filename = args[0];
        File file = new File(filename);

        try (Scanner sc = new Scanner(file)) {
            if (!sc.hasNextLine()) {
                System.out.println("Error line 1 Reason: Missing number of cities.");
                return;
            }
            int numCities;
            try {
                numCities = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error Line 1 Reason: Invalid number of cities.");
                return;
            }

            if (!sc.hasNextLine()) {
                System.out.println("Error Missing city names.");
                return;
            }
            String[] cityNames = sc.nextLine().split(" ");
            if (cityNames.length != numCities) {
                System.out.println("Error Line 2. Reason: Number of cities does not match.");
                return;
                //!!!!!!!!!!!!!!!!!!!!!! gives error in line 2
            }

            City[] cities = new City[numCities];
            for (int i = 0; i < numCities; i++) {
                cities[i] = new City(cityNames[i], i);
            }
            if (!sc.hasNextLine()) {
                System.out.println("Error Line 3 Missing number of routes.");
                return;
            }

            int numRoutes;
            try{
                numRoutes=Integer.parseInt(sc.nextLine().trim());
            }catch(NumberFormatException e){
                System.out.println("Error Line 3 Invalid number of routes.");
                return;
            }

            int[][] timeMatrix = new int[numCities][numCities];
            for (int i = 0; i < numCities; i++) {
                for (int j = 0; j < numCities; j++) {
                    timeMatrix[i][j] = -1;
                }
            }
            for (int i = 0; i < numRoutes; i++) {
                String[] routeInfo = sc.nextLine().split(" ");
                if (routeInfo.length!= 3) {
                    System.out.println("Error line: "+(i+4)+" Reason: RouteInfo structure is less then 3");
                    break;
                }
                String city1 = routeInfo[0];
                String city2 = routeInfo[1];
                int time = Integer.parseInt(routeInfo[2]);
                if (time<=0){
                    System.out.println("Error line "+(i+4)+" Invalid time");
                    return;
                }

                int city1Index = getIndex(cities, city1);
                int city2Index = getIndex(cities, city2);

                if (city1Index == -1 || city2Index == -1) {
                    System.out.println("Error line "+(i+4)+" Reason: Invalid city name. Unspecified city is first mentioned in here");
                    return;
                }
                timeMatrix[city1Index][city2Index] = time;
                timeMatrix[city2Index][city1Index] = time;
            }

            if (!sc.hasNextLine()) { //for last line
                System.out.println("Error line "+(4+numRoutes)+" Reason: Missing start and end cities.");
                return;
            }
            String[] lastLine = sc.nextLine().split(" ");
            if (lastLine.length != 2) {
                System.out.println("Error line"+(4+numRoutes)+"Reason: Input file structure.");
                return;
            }
            String startCity = lastLine[0];
            String endCity = lastLine[1];
            
            System.out.println("File read is successful!");

            WayFinder wayFinder = new WayFinder(cities, timeMatrix);
            wayFinder.findFastestRoute(startCity, endCity);


        } catch (IOException e) {
            System.out.println("Error. Reason: Can not read the file.");
        }
    }
    public static int getIndex(City[] cities, String cityName){
        for (int i = 0; i < cities.length; i++) {
            if (cities[i].getCityName().equals(cityName)) {
                return cities[i].getIndex();
            }
        }
        return -1;
    }
}
